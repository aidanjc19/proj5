import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

public class Language implements LanguageInterface {

     private String name;
     private String fileName;
     private Type type;
     private String[] keywords;

     Language(String name, String fileName, Type type) {
          setName(name);
          setFileName(fileName);
          setType(type);
          readInKeywords();
          sortKwds();
     }

     private void setName(String name) {
          if (name == null || name.isBlank()) {
               throw new IllegalArgumentException("name must not be null or empty.");
          }
          this.name = name;
     }

     private void setFileName(String fileName) {
          if (fileName == null || fileName.isBlank()) {
               throw new IllegalArgumentException("fileName must not be null or empty.");
          }
          this.fileName = fileName;
     }

     private void setType(Type type) {
          if (type == null) {
               throw new IllegalArgumentException("type must not be null.");
          }
          this.type = type;
     }

     public String getName() {
          return name;
     }

     public String getFileName() {
          return fileName;
     }

     public Type getType() {
          return type;
     }

     private void readInKeywords() {
          File keywordFile = new File(fileName);
          Scanner textScan;
          try {
               textScan = new Scanner(keywordFile);
          } catch (FileNotFoundException e) {
               keywords = new String[0];
               return;
          }

          keywords = new String[textScan.nextInt()];
          textScan.nextLine();
          for (int index = 0; index < keywords.length; index++) {
               keywords[index] = textScan.nextLine().strip();
          }
          textScan.close();
     }

     public int getKwdCount() {
          return keywords.length;
     }

     public String getKwd(int index) {
          return keywords[index];
     }

     public int findKwd(String keyword) {
          for (int index = 0; index < keywords.length; index++) {
               if (keyword.equals(keywords[index])) {
                    return index;
               }
          }
          return -1;
     }

     public int findShortestKwdLength() {
          return 1;
     }

     public int findLongestKwdLength() {
          return 1;
     }

     public void sortKwds() {
          for (int pass = 1; pass < keywords.length; pass++) {
               String temp = keywords[pass];
               int checkPos = pass - 1;
               while (checkPos >= 0 && temp.compareTo(keywords[checkPos]) < 0) {
                    keywords[checkPos + 1] = keywords[checkPos];
                    checkPos--;
               }
               keywords[checkPos + 1] = temp;
          }
     }

     public String toString() {
          return String.format("Language Name: %s, Language type: %s, Number of Keywords: %d",
                                name, type, getKwdCount());
     }
}