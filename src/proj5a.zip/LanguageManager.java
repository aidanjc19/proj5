import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class LanguageManager implements LanguageManagerInterface {

    private Language[] languages;


    //don't use try/catch
    public LanguageManager(File languageFile) throws FileNotFoundException {
        Scanner languageScan = new Scanner(languageFile);
        languages = new Language[languageScan.nextInt()];
        languageScan.nextLine();
        languageScan.nextLine();
        for (int languageIndex = 0; languageIndex < languages.length; languageIndex++) {
            String[] languageParams = languageScan.nextLine().split(",");
            languages[languageIndex] = new Language(languageParams[0], languageParams[1], LanguageInterface.Type.valueOf(languageParams[2].toUpperCase()));
        }
    }

    public int getLanguageCount() {
        return languages.length;
    }

    public Language getLanguage(int index) {
        return null;
    }

    public int findShortestKwdLength() {
        return 0;
    }

    public int findLongestKwdLength() {
        return 0;
    }

    public int findLangWithFewestKwds() {
        return 0;
    }

    public int findLangWithMostKwds() {
        return 0;
    }

    public int[] findLangKwdMatches(String keyword) {
        return new int[0];
    }

    public int[] findLangsOfType(Language.Type type) {
        return new int[0];
    }

    public void sortLangs() {

    }
}
